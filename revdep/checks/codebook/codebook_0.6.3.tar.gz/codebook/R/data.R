#' Mock BFI data
#'
#' a small mock BFI dataset with realistic values, exported from formr.
#' The dataset is self-documenting via its attributes.
#'
#' @format A data frame with 28 rows and 29 variables:
"bfi"
